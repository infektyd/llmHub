//
//  CanvasChatView.swift
//  llmHub
//
//  Chat view rendering a no-bubble transcript on a "canvas" surface.
//

import SwiftData
import SwiftUI

struct CanvasChatView: View {
    @Environment(WorkbenchViewModel.self) private var workbenchVM
    @Environment(\.modelContext) private var modelContext

    let session: ChatSessionEntity

    @State private var chatVM = ChatViewModel()
    @State private var composerText: String = ""
    @State private var thinkingPreference: ThinkingPreference = .auto

    var body: some View {
        VStack(spacing: 0) {
            transcript
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            if chatVM.isTruncated, chatVM.truncatedSessionID == session.id {
                truncationBanner
                    .frame(maxWidth: 860)
                    .padding(.horizontal, 18)
                    .padding(.bottom, 6)
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
            }

            ChatInputPanel(
                text: $composerText,
                thinkingPreference: $thinkingPreference,
                isSending: chatVM.isGenerating,
                onSend: { messageText in
                    send(text: messageText)
                },
                onStop: {
                    await chatVM.stopGeneration()
                },
                tools: chatVM.toolToggles,
                onToggleTool: { id, enabled in
                    Task { await chatVM.setToolPermission(toolID: id, enabled: enabled) }
                },
                onToolsAppear: {
                    Task { await chatVM.refreshToolToggles(modelContext: modelContext) }
                },
                stagedAttachments: chatVM.stagedAttachments,
                onAddAttachment: { chatVM.addAttachment($0) },
                onRemoveAttachment: { chatVM.removeAttachment(at: $0) },
                stagedReferences: chatVM.stagedReferences,
                onRemoveReference: { chatVM.removeReference(at: $0) }
            )
            .frame(maxWidth: 860)
            .padding(.horizontal, 18)
            .padding(.bottom, 16)
            .padding(.top, 10)
        }
        .background(AppColors.backgroundPrimary)
    }

    private var truncationBanner: some View {
        HStack(spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.yellow)
            Text("Response truncated due to max tokens.")
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(AppColors.textPrimary)
            Spacer()
            Button("Continue") {
                chatVM.continueGenerating(session: session, modelContext: modelContext)
            }
            .buttonStyle(.borderedProminent)
            .tint(AppColors.accent)
            Button("Dismiss") {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                    chatVM.isTruncated = false
                    chatVM.truncatedSessionID = nil
                }
            }
            .buttonStyle(.bordered)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background {
            RoundedRectangle(cornerRadius: AppColors.cornerRadius, style: .continuous)
                .fill(AppColors.surface.opacity(0.92))
        }
        .overlay {
            RoundedRectangle(cornerRadius: AppColors.cornerRadius, style: .continuous)
                .stroke(Color.yellow.opacity(0.35), lineWidth: AppColors.borderWidth)
        }
    }

    private var transcript: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 0) {
                    ForEach(orderedMessages) { message in
                        CanvasTranscriptRow(message: message)
                            .id(message.id)
                    }

                    if chatVM.isThinking {
                        CanvasStatusRow(text: "Thinking…")
                            .transition(.opacity)
                    }

                    if let streaming = chatVM.streamingDisplayMessage {
                        CanvasMessageRow(role: .assistant, markdown: streaming.content)
                            .id(streaming.id)
                            .transition(.opacity)
                    }
                }
                .padding(.vertical, 18)
                .frame(maxWidth: 860)
                .frame(maxWidth: .infinity)
                .padding(.top, 10)
            }
            .onChange(of: chatVM.lastVisibleMessageID) { _, newValue in
                guard let id = newValue else { return }
                withAnimation(.easeOut(duration: 0.25)) {
                    proxy.scrollTo(id, anchor: .bottom)
                }
            }
            .onAppear {
                if let lastID = orderedMessages.last?.id {
                    proxy.scrollTo(lastID, anchor: .bottom)
                }
            }
        }
    }

    private var orderedMessages: [ChatMessageEntity] {
        session.messages.sorted { $0.createdAt < $1.createdAt }
    }

    private func send(text: String) {
        let trimmedText = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedText.isEmpty || !chatVM.stagedAttachments.isEmpty else { return }
        composerText = ""

        chatVM.sendMessage(
            messageText: trimmedText,
            attachments: chatVM.stagedAttachments.isEmpty ? nil : chatVM.stagedAttachments,
            session: session,
            modelContext: modelContext,
            selectedProvider: workbenchVM.selectedProvider,
            selectedModel: workbenchVM.selectedModel,
            thinkingPreference: thinkingPreference
        )
    }
}

private struct CanvasTranscriptRow: View {
    let message: ChatMessageEntity

    var body: some View {
        switch message.asDomain().role {
        case .user, .assistant:
            if let toolCalls = toolCalls(for: message), !toolCalls.isEmpty {
                VStack(spacing: 0) {
                    if !message.content.isEmpty {
                        CanvasMessageRow(role: message.asDomain().role, markdown: message.content)
                    }

                    CanvasToolSectionView(
                        section: CanvasToolSection(
                            title: toolCalls.count == 1 ? "1 step" : "\(toolCalls.count) steps",
                            steps: toolCalls.map { .init(title: $0.name, status: .done) }
                        )
                    )
                    .padding(.horizontal, 26)
                    .padding(.vertical, 10)
                }
            } else {
                CanvasMessageRow(role: message.asDomain().role, markdown: message.content)
            }

        case .tool:
            CanvasToolOutputRow(toolCallID: message.toolCallID, output: message.content)

        case .system:
            CanvasStatusRow(text: message.content)
        }
    }

    private func toolCalls(for message: ChatMessageEntity) -> [ToolCall]? {
        guard let toolCallsData = message.toolCallsData else { return nil }
        return try? JSONDecoder().decode([ToolCall].self, from: toolCallsData)
    }
}

private struct CanvasToolOutputRow: View {
    let toolCallID: String?
    let output: String

    var body: some View {
        DisclosureGroup {
            ScrollView(.horizontal) {
                Text(output)
                    .font(AppColors.monoFont)
                    .foregroundStyle(AppColors.textPrimary.opacity(0.9))
                    .textSelection(.enabled)
                    .padding(.top, 10)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        } label: {
            HStack(spacing: 10) {
                Text("Tool Output")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(AppColors.textPrimary)
                if let toolCallID {
                    Text(toolCallID)
                        .font(.system(size: 12))
                        .foregroundStyle(AppColors.textTertiary)
                        .lineLimit(1)
                }
                Spacer()
            }
        }
        .disclosureGroupStyle(.automatic)
        .padding(14)
        .background {
            RoundedRectangle(cornerRadius: AppColors.cornerRadius, style: .continuous)
                .fill(AppColors.surface.opacity(0.92))
        }
        .overlay {
            RoundedRectangle(cornerRadius: AppColors.cornerRadius, style: .continuous)
                .stroke(AppColors.textPrimary.opacity(0.10), lineWidth: AppColors.borderWidth)
        }
        .padding(.horizontal, 26)
        .padding(.vertical, 10)
    }
}

private struct CanvasStatusRow: View {
    let text: String

    var body: some View {
        HStack(spacing: 10) {
            ProgressView()
                .controlSize(.small)
            Text(text)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(AppColors.textSecondary)
            Spacer()
        }
        .padding(.horizontal, 26)
        .padding(.vertical, 10)
    }
}

#Preview("Canvas Chat View") {
    CanvasChatView(session: MockData.chatSession())
        .previewEnvironment()
        .preferredColorScheme(.dark)
}
